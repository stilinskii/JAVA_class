package src.java_test.test10;

public interface Bonus {
    
     void incentive(int pay);
}
